# Zomato-Landing-Page-Clone
Exact Zomato Landing Page Clone using HTML and CSS 
# Note
Make sure that your HTML, CSS files and the images are in the same folder before running the code
# Result
Do check out the cloned website in About section
